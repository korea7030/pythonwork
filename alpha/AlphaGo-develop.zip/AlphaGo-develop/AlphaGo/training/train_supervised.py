# run CNNPolicy.create_network()
# randomly select a tensor from the training folder
# train

class MCTS(object):
	pass

class ParallelMCTS(MCTS):
	pass